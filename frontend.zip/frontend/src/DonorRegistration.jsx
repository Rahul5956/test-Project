import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const DonorRegistration = () => {
  const [isRegistered, setIsRegistered] = useState(false);
  const navigate = useNavigate();

  const handleRegistration = (event) => {
    event.preventDefault();

    // Perform your registration logic here

    setIsRegistered(true);

    // Redirect to landing page after a delay
    setTimeout(() => {
      navigate('/'); // Redirect to the LandingPage after successful registration
    }, 3000); // 3 seconds delay before redirection
  };

  return (
    <div className="flex justify-center items-center h-screen bg-gray-100">
      <form onSubmit={handleRegistration} className="bg-white p-6 rounded shadow-md w-full max-w-md">
        <h2 className="text-2xl font-bold mb-4">Donor Registration</h2>
        <input type="text" placeholder="Username" className="border p-2 mb-4 w-full" required />
        <input type="email" placeholder="Email" className="border p-2 mb-4 w-full" required />
        <input type="password" placeholder="Password" className="border p-2 mb-4 w-full" required />
        <button type="submit" className="bg-blue-500 text-white py-2 px-4 rounded">
          Register
        </button>
      </form>

      {isRegistered && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
          <div className="bg-white p-4 rounded shadow-lg">
            <h3 className="text-xl font-bold mb-2">Registration Successful!</h3>
            <p>Please login.</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default DonorRegistration;
