import './App.css'
import AuthPage from './AuthPage'

function App() {
  return (
    <>
    <AuthPage/>
    </>
  )
}

export default App;
