import React from 'react';
import { Routes, Route } from 'react-router-dom';
import LandingPage from './LandingPage'; // Import the new landing page
import DonorLogin from './DonorLogin';
import DonorRegistration from './DonorRegistration';
import NGOLogin from './NGOLogin';
import NGORegistration from './NGORegistration';

const MainRouter = () => {
  return (
    <Routes>
        <Route path="/" element={<LandingPage />} /> 
      <Route path="/donor-login" element={<DonorLogin />} />
      <Route path="/donor-registration" element={<DonorRegistration />} />
      <Route path="/ngo-login" element={<NGOLogin />} />
      <Route path="/ngo-registration" element={<NGORegistration />} />
    </Routes>
  );
};

export default MainRouter;
